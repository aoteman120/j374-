const base = {
    get() {
        return {
            url : "http://localhost:8080/ssmwr8nn/",
            name: "ssmwr8nn",
            // 退出到首页链接
            indexUrl: ''
        };
    },
    getProjectName(){
        return {
            projectName: "气象百事通系统"
        } 
    }
}
export default base
