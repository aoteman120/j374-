package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.KongqizhuangkuangEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.KongqizhuangkuangVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.KongqizhuangkuangView;


/**
 * 空气状况
 *
 * @author 
 * @email 
 * @date 2022-04-23 13:58:33
 */
public interface KongqizhuangkuangService extends IService<KongqizhuangkuangEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<KongqizhuangkuangVO> selectListVO(Wrapper<KongqizhuangkuangEntity> wrapper);
   	
   	KongqizhuangkuangVO selectVO(@Param("ew") Wrapper<KongqizhuangkuangEntity> wrapper);
   	
   	List<KongqizhuangkuangView> selectListView(Wrapper<KongqizhuangkuangEntity> wrapper);
   	
   	KongqizhuangkuangView selectView(@Param("ew") Wrapper<KongqizhuangkuangEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<KongqizhuangkuangEntity> wrapper);
   	

    List<Map<String, Object>> selectValue(Map<String, Object> params,Wrapper<KongqizhuangkuangEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params,Wrapper<KongqizhuangkuangEntity> wrapper);

    List<Map<String, Object>> selectGroup(Map<String, Object> params,Wrapper<KongqizhuangkuangEntity> wrapper);
}

