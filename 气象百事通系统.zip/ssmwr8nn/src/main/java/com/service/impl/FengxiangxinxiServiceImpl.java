package com.service.impl;

import org.springframework.stereotype.Service;
import java.util.Map;
import java.util.List;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.mapper.EntityWrapper;
import com.baomidou.mybatisplus.plugins.Page;
import com.baomidou.mybatisplus.service.impl.ServiceImpl;
import com.utils.PageUtils;
import com.utils.Query;


import com.dao.FengxiangxinxiDao;
import com.entity.FengxiangxinxiEntity;
import com.service.FengxiangxinxiService;
import com.entity.vo.FengxiangxinxiVO;
import com.entity.view.FengxiangxinxiView;

@Service("fengxiangxinxiService")
public class FengxiangxinxiServiceImpl extends ServiceImpl<FengxiangxinxiDao, FengxiangxinxiEntity> implements FengxiangxinxiService {
	

    @Override
    public PageUtils queryPage(Map<String, Object> params) {
        Page<FengxiangxinxiEntity> page = this.selectPage(
                new Query<FengxiangxinxiEntity>(params).getPage(),
                new EntityWrapper<FengxiangxinxiEntity>()
        );
        return new PageUtils(page);
    }
    
    @Override
	public PageUtils queryPage(Map<String, Object> params, Wrapper<FengxiangxinxiEntity> wrapper) {
		  Page<FengxiangxinxiView> page =new Query<FengxiangxinxiView>(params).getPage();
	        page.setRecords(baseMapper.selectListView(page,wrapper));
	    	PageUtils pageUtil = new PageUtils(page);
	    	return pageUtil;
 	}
    
    @Override
	public List<FengxiangxinxiVO> selectListVO(Wrapper<FengxiangxinxiEntity> wrapper) {
 		return baseMapper.selectListVO(wrapper);
	}
	
	@Override
	public FengxiangxinxiVO selectVO(Wrapper<FengxiangxinxiEntity> wrapper) {
 		return baseMapper.selectVO(wrapper);
	}
	
	@Override
	public List<FengxiangxinxiView> selectListView(Wrapper<FengxiangxinxiEntity> wrapper) {
		return baseMapper.selectListView(wrapper);
	}

	@Override
	public FengxiangxinxiView selectView(Wrapper<FengxiangxinxiEntity> wrapper) {
		return baseMapper.selectView(wrapper);
	}

    @Override
    public List<Map<String, Object>> selectValue(Map<String, Object> params, Wrapper<FengxiangxinxiEntity> wrapper) {
        return baseMapper.selectValue(params, wrapper);
    }

    @Override
    public List<Map<String, Object>> selectTimeStatValue(Map<String, Object> params, Wrapper<FengxiangxinxiEntity> wrapper) {
        return baseMapper.selectTimeStatValue(params, wrapper);
    }

    @Override
    public List<Map<String, Object>> selectGroup(Map<String, Object> params, Wrapper<FengxiangxinxiEntity> wrapper) {
        return baseMapper.selectGroup(params, wrapper);
    }

}
