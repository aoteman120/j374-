package com.service;

import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.service.IService;
import com.utils.PageUtils;
import com.entity.QihouxinxiEntity;
import java.util.List;
import java.util.Map;
import com.entity.vo.QihouxinxiVO;
import org.apache.ibatis.annotations.Param;
import com.entity.view.QihouxinxiView;


/**
 * 气候信息
 *
 * @author 
 * @email 
 * @date 2022-04-23 13:58:32
 */
public interface QihouxinxiService extends IService<QihouxinxiEntity> {

    PageUtils queryPage(Map<String, Object> params);
    
   	List<QihouxinxiVO> selectListVO(Wrapper<QihouxinxiEntity> wrapper);
   	
   	QihouxinxiVO selectVO(@Param("ew") Wrapper<QihouxinxiEntity> wrapper);
   	
   	List<QihouxinxiView> selectListView(Wrapper<QihouxinxiEntity> wrapper);
   	
   	QihouxinxiView selectView(@Param("ew") Wrapper<QihouxinxiEntity> wrapper);
   	
   	PageUtils queryPage(Map<String, Object> params,Wrapper<QihouxinxiEntity> wrapper);
   	

}

