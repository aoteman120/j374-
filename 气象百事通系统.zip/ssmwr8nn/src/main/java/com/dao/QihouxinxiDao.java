package com.dao;

import com.entity.QihouxinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.QihouxinxiVO;
import com.entity.view.QihouxinxiView;


/**
 * 气候信息
 * 
 * @author 
 * @email 
 * @date 2022-04-23 13:58:32
 */
public interface QihouxinxiDao extends BaseMapper<QihouxinxiEntity> {
	
	List<QihouxinxiVO> selectListVO(@Param("ew") Wrapper<QihouxinxiEntity> wrapper);
	
	QihouxinxiVO selectVO(@Param("ew") Wrapper<QihouxinxiEntity> wrapper);
	
	List<QihouxinxiView> selectListView(@Param("ew") Wrapper<QihouxinxiEntity> wrapper);

	List<QihouxinxiView> selectListView(Pagination page,@Param("ew") Wrapper<QihouxinxiEntity> wrapper);
	
	QihouxinxiView selectView(@Param("ew") Wrapper<QihouxinxiEntity> wrapper);
	

}
