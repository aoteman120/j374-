package com.dao;

import com.entity.FengqiangxinxiEntity;
import com.baomidou.mybatisplus.mapper.BaseMapper;
import java.util.List;
import java.util.Map;
import com.baomidou.mybatisplus.mapper.Wrapper;
import com.baomidou.mybatisplus.plugins.pagination.Pagination;

import org.apache.ibatis.annotations.Param;
import com.entity.vo.FengqiangxinxiVO;
import com.entity.view.FengqiangxinxiView;


/**
 * 风强信息
 * 
 * @author 
 * @email 
 * @date 2022-04-23 13:58:33
 */
public interface FengqiangxinxiDao extends BaseMapper<FengqiangxinxiEntity> {
	
	List<FengqiangxinxiVO> selectListVO(@Param("ew") Wrapper<FengqiangxinxiEntity> wrapper);
	
	FengqiangxinxiVO selectVO(@Param("ew") Wrapper<FengqiangxinxiEntity> wrapper);
	
	List<FengqiangxinxiView> selectListView(@Param("ew") Wrapper<FengqiangxinxiEntity> wrapper);

	List<FengqiangxinxiView> selectListView(Pagination page,@Param("ew") Wrapper<FengqiangxinxiEntity> wrapper);
	
	FengqiangxinxiView selectView(@Param("ew") Wrapper<FengqiangxinxiEntity> wrapper);
	

    List<Map<String, Object>> selectValue(@Param("params")Map<String, Object> params,@Param("ew") Wrapper<FengqiangxinxiEntity> wrapper);

    List<Map<String, Object>> selectTimeStatValue(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<FengqiangxinxiEntity> wrapper);

    List<Map<String, Object>> selectGroup(@Param("params") Map<String, Object> params,@Param("ew") Wrapper<FengqiangxinxiEntity> wrapper);
}
