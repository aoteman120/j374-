package com.entity;

import com.baomidou.mybatisplus.annotations.TableId;
import com.baomidou.mybatisplus.annotations.TableName;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import java.lang.reflect.InvocationTargetException;

import java.io.Serializable;
import java.util.Date;
import java.util.List;

import org.springframework.format.annotation.DateTimeFormat;
import com.fasterxml.jackson.annotation.JsonFormat;
import org.apache.commons.beanutils.BeanUtils;
import com.baomidou.mybatisplus.annotations.TableField;
import com.baomidou.mybatisplus.enums.FieldFill;
import com.baomidou.mybatisplus.enums.IdType;


/**
 * 气候信息
 * 数据库通用操作实体类（普通增删改查）
 * @author 
 * @email 
 * @date 2022-04-23 13:58:32
 */
@TableName("qihouxinxi")
public class QihouxinxiEntity<T> implements Serializable {
	private static final long serialVersionUID = 1L;


	public QihouxinxiEntity() {
		
	}
	
	public QihouxinxiEntity(T t) {
		try {
			BeanUtils.copyProperties(this, t);
		} catch (IllegalAccessException | InvocationTargetException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	/**
	 * 主键id
	 */
	@TableId
	private Long id;
	/**
	 * 天气名称
	 */
					
	private String tianqimingcheng;
	
	/**
	 * 图片
	 */
					
	private String tupian;
	
	/**
	 * 均值
	 */
					
	private String junzhi;
	
	/**
	 * 总量
	 */
					
	private String zongliang;
	
	/**
	 * 频率
	 */
					
	private String pinlv;
	
	/**
	 * 极值
	 */
					
	private String jizhi;
	
	/**
	 * 变率
	 */
					
	private String bianlv;
	
	/**
	 * 初始日期
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
	@DateTimeFormat 		
	private Date chushiriqi;
	
	/**
	 * 持续日数
	 */
					
	private String chixurishu;
	
	/**
	 * 结束日期
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
	@DateTimeFormat 		
	private Date jieshuriqi;
	
	/**
	 * 气候详情
	 */
					
	private String qihouxiangqing;
	
	/**
	 * 发布时间
	 */
				
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd")
	@DateTimeFormat 		
	private Date fabushijian;
	
	/**
	 * 用户账号
	 */
					
	private String yonghuzhanghao;
	
	/**
	 * 用户姓名
	 */
					
	private String yonghuxingming;
	
	/**
	 * 城市名称
	 */
					
	private String chengshimingcheng;
	
	
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat
	private Date addtime;

	public Date getAddtime() {
		return addtime;
	}
	public void setAddtime(Date addtime) {
		this.addtime = addtime;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}
	/**
	 * 设置：天气名称
	 */
	public void setTianqimingcheng(String tianqimingcheng) {
		this.tianqimingcheng = tianqimingcheng;
	}
	/**
	 * 获取：天气名称
	 */
	public String getTianqimingcheng() {
		return tianqimingcheng;
	}
	/**
	 * 设置：图片
	 */
	public void setTupian(String tupian) {
		this.tupian = tupian;
	}
	/**
	 * 获取：图片
	 */
	public String getTupian() {
		return tupian;
	}
	/**
	 * 设置：均值
	 */
	public void setJunzhi(String junzhi) {
		this.junzhi = junzhi;
	}
	/**
	 * 获取：均值
	 */
	public String getJunzhi() {
		return junzhi;
	}
	/**
	 * 设置：总量
	 */
	public void setZongliang(String zongliang) {
		this.zongliang = zongliang;
	}
	/**
	 * 获取：总量
	 */
	public String getZongliang() {
		return zongliang;
	}
	/**
	 * 设置：频率
	 */
	public void setPinlv(String pinlv) {
		this.pinlv = pinlv;
	}
	/**
	 * 获取：频率
	 */
	public String getPinlv() {
		return pinlv;
	}
	/**
	 * 设置：极值
	 */
	public void setJizhi(String jizhi) {
		this.jizhi = jizhi;
	}
	/**
	 * 获取：极值
	 */
	public String getJizhi() {
		return jizhi;
	}
	/**
	 * 设置：变率
	 */
	public void setBianlv(String bianlv) {
		this.bianlv = bianlv;
	}
	/**
	 * 获取：变率
	 */
	public String getBianlv() {
		return bianlv;
	}
	/**
	 * 设置：初始日期
	 */
	public void setChushiriqi(Date chushiriqi) {
		this.chushiriqi = chushiriqi;
	}
	/**
	 * 获取：初始日期
	 */
	public Date getChushiriqi() {
		return chushiriqi;
	}
	/**
	 * 设置：持续日数
	 */
	public void setChixurishu(String chixurishu) {
		this.chixurishu = chixurishu;
	}
	/**
	 * 获取：持续日数
	 */
	public String getChixurishu() {
		return chixurishu;
	}
	/**
	 * 设置：结束日期
	 */
	public void setJieshuriqi(Date jieshuriqi) {
		this.jieshuriqi = jieshuriqi;
	}
	/**
	 * 获取：结束日期
	 */
	public Date getJieshuriqi() {
		return jieshuriqi;
	}
	/**
	 * 设置：气候详情
	 */
	public void setQihouxiangqing(String qihouxiangqing) {
		this.qihouxiangqing = qihouxiangqing;
	}
	/**
	 * 获取：气候详情
	 */
	public String getQihouxiangqing() {
		return qihouxiangqing;
	}
	/**
	 * 设置：发布时间
	 */
	public void setFabushijian(Date fabushijian) {
		this.fabushijian = fabushijian;
	}
	/**
	 * 获取：发布时间
	 */
	public Date getFabushijian() {
		return fabushijian;
	}
	/**
	 * 设置：用户账号
	 */
	public void setYonghuzhanghao(String yonghuzhanghao) {
		this.yonghuzhanghao = yonghuzhanghao;
	}
	/**
	 * 获取：用户账号
	 */
	public String getYonghuzhanghao() {
		return yonghuzhanghao;
	}
	/**
	 * 设置：用户姓名
	 */
	public void setYonghuxingming(String yonghuxingming) {
		this.yonghuxingming = yonghuxingming;
	}
	/**
	 * 获取：用户姓名
	 */
	public String getYonghuxingming() {
		return yonghuxingming;
	}
	/**
	 * 设置：城市名称
	 */
	public void setChengshimingcheng(String chengshimingcheng) {
		this.chengshimingcheng = chengshimingcheng;
	}
	/**
	 * 获取：城市名称
	 */
	public String getChengshimingcheng() {
		return chengshimingcheng;
	}

}
