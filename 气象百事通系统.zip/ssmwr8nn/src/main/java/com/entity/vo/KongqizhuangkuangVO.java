package com.entity.vo;

import com.entity.KongqizhuangkuangEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;

import java.io.Serializable;
 

/**
 * 空气状况
 * 手机端接口返回实体辅助类 
 * （主要作用去除一些不必要的字段）
 * @author 
 * @email 
 * @date 2022-04-23 13:58:33
 */
public class KongqizhuangkuangVO  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 悬浮颗粒物
	 */
	
	private String xuanfukeliwu;
		
	/**
	 * 可吸入颗粒
	 */
	
	private String kexirukeli;
		
	/**
	 * 细颗粒物
	 */
	
	private String xikeliwu;
		
	/**
	 * 空气质量指数
	 */
	
	private String kongqizhiliangzhishu;
		
	/**
	 * 指数级别
	 */
	
	private String zhishujibie;
		
	/**
	 * 质量指数
	 */
	
	private String zhiliangzhishu;
		
	/**
	 * 记录时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date jilushijian;
		
	/**
	 * 用户账号
	 */
	
	private String yonghuzhanghao;
		
	/**
	 * 用户姓名
	 */
	
	private String yonghuxingming;
		
	/**
	 * 城市名称
	 */
	
	private String chengshimingcheng;
				
	
	/**
	 * 设置：悬浮颗粒物
	 */
	 
	public void setXuanfukeliwu(String xuanfukeliwu) {
		this.xuanfukeliwu = xuanfukeliwu;
	}
	
	/**
	 * 获取：悬浮颗粒物
	 */
	public String getXuanfukeliwu() {
		return xuanfukeliwu;
	}
				
	
	/**
	 * 设置：可吸入颗粒
	 */
	 
	public void setKexirukeli(String kexirukeli) {
		this.kexirukeli = kexirukeli;
	}
	
	/**
	 * 获取：可吸入颗粒
	 */
	public String getKexirukeli() {
		return kexirukeli;
	}
				
	
	/**
	 * 设置：细颗粒物
	 */
	 
	public void setXikeliwu(String xikeliwu) {
		this.xikeliwu = xikeliwu;
	}
	
	/**
	 * 获取：细颗粒物
	 */
	public String getXikeliwu() {
		return xikeliwu;
	}
				
	
	/**
	 * 设置：空气质量指数
	 */
	 
	public void setKongqizhiliangzhishu(String kongqizhiliangzhishu) {
		this.kongqizhiliangzhishu = kongqizhiliangzhishu;
	}
	
	/**
	 * 获取：空气质量指数
	 */
	public String getKongqizhiliangzhishu() {
		return kongqizhiliangzhishu;
	}
				
	
	/**
	 * 设置：指数级别
	 */
	 
	public void setZhishujibie(String zhishujibie) {
		this.zhishujibie = zhishujibie;
	}
	
	/**
	 * 获取：指数级别
	 */
	public String getZhishujibie() {
		return zhishujibie;
	}
				
	
	/**
	 * 设置：质量指数
	 */
	 
	public void setZhiliangzhishu(String zhiliangzhishu) {
		this.zhiliangzhishu = zhiliangzhishu;
	}
	
	/**
	 * 获取：质量指数
	 */
	public String getZhiliangzhishu() {
		return zhiliangzhishu;
	}
				
	
	/**
	 * 设置：记录时间
	 */
	 
	public void setJilushijian(Date jilushijian) {
		this.jilushijian = jilushijian;
	}
	
	/**
	 * 获取：记录时间
	 */
	public Date getJilushijian() {
		return jilushijian;
	}
				
	
	/**
	 * 设置：用户账号
	 */
	 
	public void setYonghuzhanghao(String yonghuzhanghao) {
		this.yonghuzhanghao = yonghuzhanghao;
	}
	
	/**
	 * 获取：用户账号
	 */
	public String getYonghuzhanghao() {
		return yonghuzhanghao;
	}
				
	
	/**
	 * 设置：用户姓名
	 */
	 
	public void setYonghuxingming(String yonghuxingming) {
		this.yonghuxingming = yonghuxingming;
	}
	
	/**
	 * 获取：用户姓名
	 */
	public String getYonghuxingming() {
		return yonghuxingming;
	}
				
	
	/**
	 * 设置：城市名称
	 */
	 
	public void setChengshimingcheng(String chengshimingcheng) {
		this.chengshimingcheng = chengshimingcheng;
	}
	
	/**
	 * 获取：城市名称
	 */
	public String getChengshimingcheng() {
		return chengshimingcheng;
	}
			
}
