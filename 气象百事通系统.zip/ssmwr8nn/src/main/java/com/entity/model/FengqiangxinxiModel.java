package com.entity.model;

import com.entity.FengqiangxinxiEntity;

import com.baomidou.mybatisplus.annotations.TableName;
import com.fasterxml.jackson.annotation.JsonFormat;
import java.util.Date;
import org.springframework.format.annotation.DateTimeFormat;
import java.io.Serializable;
 

/**
 * 风强信息
 * 接收传参的实体类  
 *（实际开发中配合移动端接口开发手动去掉些没用的字段， 后端一般用entity就够用了） 
 * 取自ModelAndView 的model名称
 * @author 
 * @email 
 * @date 2022-04-23 13:58:33
 */
public class FengqiangxinxiModel  implements Serializable {
	private static final long serialVersionUID = 1L;

	 			
	/**
	 * 风速
	 */
	
	private String fengsu;
		
	/**
	 * 陆地物象
	 */
	
	private String ludiwuxiang;
		
	/**
	 * 海面波浪
	 */
	
	private String haimianbolang;
		
	/**
	 * 浪高
	 */
	
	private String langgao;
		
	/**
	 * 记录时间
	 */
		
	@JsonFormat(locale="zh", timezone="GMT+8", pattern="yyyy-MM-dd HH:mm:ss")
	@DateTimeFormat 
	private Date jilushijian;
		
	/**
	 * 用户账号
	 */
	
	private String yonghuzhanghao;
		
	/**
	 * 用户姓名
	 */
	
	private String yonghuxingming;
		
	/**
	 * 城市名称
	 */
	
	private String chengshimingcheng;
				
	
	/**
	 * 设置：风速
	 */
	 
	public void setFengsu(String fengsu) {
		this.fengsu = fengsu;
	}
	
	/**
	 * 获取：风速
	 */
	public String getFengsu() {
		return fengsu;
	}
				
	
	/**
	 * 设置：陆地物象
	 */
	 
	public void setLudiwuxiang(String ludiwuxiang) {
		this.ludiwuxiang = ludiwuxiang;
	}
	
	/**
	 * 获取：陆地物象
	 */
	public String getLudiwuxiang() {
		return ludiwuxiang;
	}
				
	
	/**
	 * 设置：海面波浪
	 */
	 
	public void setHaimianbolang(String haimianbolang) {
		this.haimianbolang = haimianbolang;
	}
	
	/**
	 * 获取：海面波浪
	 */
	public String getHaimianbolang() {
		return haimianbolang;
	}
				
	
	/**
	 * 设置：浪高
	 */
	 
	public void setLanggao(String langgao) {
		this.langgao = langgao;
	}
	
	/**
	 * 获取：浪高
	 */
	public String getLanggao() {
		return langgao;
	}
				
	
	/**
	 * 设置：记录时间
	 */
	 
	public void setJilushijian(Date jilushijian) {
		this.jilushijian = jilushijian;
	}
	
	/**
	 * 获取：记录时间
	 */
	public Date getJilushijian() {
		return jilushijian;
	}
				
	
	/**
	 * 设置：用户账号
	 */
	 
	public void setYonghuzhanghao(String yonghuzhanghao) {
		this.yonghuzhanghao = yonghuzhanghao;
	}
	
	/**
	 * 获取：用户账号
	 */
	public String getYonghuzhanghao() {
		return yonghuzhanghao;
	}
				
	
	/**
	 * 设置：用户姓名
	 */
	 
	public void setYonghuxingming(String yonghuxingming) {
		this.yonghuxingming = yonghuxingming;
	}
	
	/**
	 * 获取：用户姓名
	 */
	public String getYonghuxingming() {
		return yonghuxingming;
	}
				
	
	/**
	 * 设置：城市名称
	 */
	 
	public void setChengshimingcheng(String chengshimingcheng) {
		this.chengshimingcheng = chengshimingcheng;
	}
	
	/**
	 * 获取：城市名称
	 */
	public String getChengshimingcheng() {
		return chengshimingcheng;
	}
			
}
